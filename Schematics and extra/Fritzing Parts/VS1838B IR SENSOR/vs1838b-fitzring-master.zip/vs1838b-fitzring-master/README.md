# vs1838b-fitzring
vs1838b infrared receiver fitzring part
